window.onload = () => {
  const navMenu = document.querySelector('.nav-menu');
  const navItems = document.querySelectorAll('.nav-item');
  const hamburger = document.querySelector('.nav-toggle');
  
  const toggle = e => e.classList.toggle('is-active');
  const toggleNav = ({ target }) => Array.from(navMenu.classList).includes('is-active') ? toggle(navMenu) : null;

  hamburger.addEventListener('click', () => toggle(navMenu, 'is-active'));
  Array.from(navItems).forEach(e => e.addEventListener('click', toggleNav));
}

document.addEventListener('DOMContentLoaded', function() {
  // Example: Add a class to trigger animations after DOM is loaded
  document.querySelector('.avatar').classList.add('avatar-loaded');
  document.querySelector('.intro').classList.add('intro-loaded');
});
